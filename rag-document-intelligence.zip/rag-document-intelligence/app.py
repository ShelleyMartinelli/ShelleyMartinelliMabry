"""
RAG Document Intelligence System
Built by Shosi | AI Operations Engineer

A production-quality Retrieval-Augmented Generation (RAG) application that
allows users to upload PDF documents and ask natural language questions,
with every answer grounded in cited source passages.
"""

import os
import sys
import tempfile
from pathlib import Path

import streamlit as st

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from rag_engine import (
    get_embeddings,
    get_vector_store,
    ingest_pdf,
    get_ingested_documents,
    delete_document,
    build_rag_chain,
    query_documents,
)

# Suppress deprecation warnings from langchain-community
import warnings
warnings.filterwarnings('ignore', category=DeprecationWarning)

# ─── Page Configuration ───────────────────────────────────────────────────────

st.set_page_config(
    page_title="RAG Document Intelligence",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ───────────────────────────────────────────────────────────────

st.markdown("""
<style>
    /* Main background */
    .stApp {
        background-color: #0e1117;
    }

    /* Header */
    .main-header {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        padding: 2rem 2.5rem;
        border-radius: 12px;
        margin-bottom: 1.5rem;
        border: 1px solid #2d3561;
    }
    .main-header h1 {
        color: #e0e0ff;
        font-size: 2rem;
        font-weight: 700;
        margin: 0;
        letter-spacing: -0.5px;
    }
    .main-header p {
        color: #8892b0;
        font-size: 0.95rem;
        margin: 0.4rem 0 0 0;
    }

    /* Answer box */
    .answer-box {
        background: #1a1a2e;
        border: 1px solid #2d3561;
        border-left: 4px solid #6c63ff;
        border-radius: 8px;
        padding: 1.5rem;
        margin: 1rem 0;
        color: #ccd6f6;
        line-height: 1.7;
        font-size: 0.97rem;
    }

    /* Citation card */
    .citation-card {
        background: #0d1117;
        border: 1px solid #2d3561;
        border-left: 3px solid #64ffda;
        border-radius: 6px;
        padding: 1rem 1.2rem;
        margin: 0.5rem 0;
    }
    .citation-header {
        color: #64ffda;
        font-weight: 600;
        font-size: 0.85rem;
        margin-bottom: 0.4rem;
        font-family: 'Courier New', monospace;
    }
    .citation-excerpt {
        color: #8892b0;
        font-size: 0.82rem;
        line-height: 1.5;
        font-style: italic;
    }

    /* Status badges */
    .badge-success {
        background: #064e3b;
        color: #34d399;
        padding: 2px 10px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .badge-info {
        background: #1e3a5f;
        color: #60a5fa;
        padding: 2px 10px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
    }

    /* Sidebar */
    .sidebar-section {
        background: #1a1a2e;
        border: 1px solid #2d3561;
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1rem;
    }
    .sidebar-section h4 {
        color: #ccd6f6;
        font-size: 0.85rem;
        font-weight: 600;
        margin: 0 0 0.5rem 0;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* Doc list item */
    .doc-item {
        background: #0d1117;
        border: 1px solid #2d3561;
        border-radius: 6px;
        padding: 0.5rem 0.8rem;
        margin: 0.3rem 0;
        color: #8892b0;
        font-size: 0.82rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    /* Question input */
    .stTextArea textarea {
        background-color: #1a1a2e !important;
        border: 1px solid #2d3561 !important;
        color: #ccd6f6 !important;
        border-radius: 8px !important;
    }

    /* Buttons */
    .stButton > button {
        background: linear-gradient(135deg, #6c63ff, #4f46e5);
        color: white;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        padding: 0.5rem 1.5rem;
        transition: all 0.2s;
    }
    .stButton > button:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 15px rgba(108, 99, 255, 0.4);
    }

    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}

    /* Metric cards */
    .metric-row {
        display: flex;
        gap: 1rem;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background: #1a1a2e;
        border: 1px solid #2d3561;
        border-radius: 8px;
        padding: 1rem 1.5rem;
        flex: 1;
        text-align: center;
    }
    .metric-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: #6c63ff;
    }
    .metric-label {
        font-size: 0.75rem;
        color: #8892b0;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* Divider */
    hr {
        border-color: #2d3561 !important;
    }
</style>
""", unsafe_allow_html=True)


# ─── Session State Initialization ─────────────────────────────────────────────

@st.cache_resource(show_spinner=False)
def load_rag_components():
    """Load embeddings and vector store once, cached across reruns."""
    embeddings = get_embeddings()
    vector_store = get_vector_store(embeddings)
    return embeddings, vector_store


def get_chain(vector_store):
    """Build the RAG chain and retriever (cached in session state)."""
    if "rag_chain" not in st.session_state or "rag_retriever" not in st.session_state:
        chain, retriever = build_rag_chain(vector_store)
        st.session_state.rag_chain = chain
        st.session_state.rag_retriever = retriever
    return st.session_state.rag_chain, st.session_state.rag_retriever


if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

if "processing" not in st.session_state:
    st.session_state.processing = False


# ─── Load Core Components ─────────────────────────────────────────────────────

with st.spinner("Initializing AI engine..."):
    embeddings, vector_store = load_rag_components()

rag_chain, rag_retriever = get_chain(vector_store)
ingested_docs = get_ingested_documents(vector_store)


# ─── Sidebar ──────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("## 📄 Document Intelligence")
    st.markdown("---")

    # Upload Section
    st.markdown("### Upload Documents")
    uploaded_files = st.file_uploader(
        "Drop PDF files here",
        type=["pdf"],
        accept_multiple_files=True,
        help="Upload one or more PDF files to analyze",
        label_visibility="collapsed",
    )

    if uploaded_files:
        if st.button("⚡ Process Documents", use_container_width=True):
            progress_bar = st.progress(0)
            status_msgs = []

            for i, uploaded_file in enumerate(uploaded_files):
                with tempfile.NamedTemporaryFile(
                    delete=False, suffix=".pdf", prefix="rag_"
                ) as tmp:
                    tmp.write(uploaded_file.read())
                    tmp_path = tmp.name

                with st.spinner(f"Processing {uploaded_file.name}..."):
                    result = ingest_pdf(tmp_path, vector_store)

                os.unlink(tmp_path)

                if result["status"] == "ingested":
                    status_msgs.append(
                        f"✅ **{result['filename']}** — {result['chunks']} chunks indexed"
                    )
                elif result["status"] == "already_ingested":
                    status_msgs.append(
                        f"ℹ️ **{result['filename']}** — already in knowledge base"
                    )
                else:
                    status_msgs.append(f"⚠️ **{result['filename']}** — could not process")

                progress_bar.progress((i + 1) / len(uploaded_files))

            # Refresh chain and docs
            new_chain, new_retriever = build_rag_chain(vector_store)
            st.session_state.rag_chain = new_chain
            st.session_state.rag_retriever = new_retriever
            st.rerun()

    st.markdown("---")

    # Knowledge Base Status
    st.markdown("### Knowledge Base")
    ingested_docs = get_ingested_documents(vector_store)

    if ingested_docs:
        st.markdown(
            f'<div class="badge-success">● {len(ingested_docs)} document(s) loaded</div>',
            unsafe_allow_html=True,
        )
        st.markdown("")
        for doc in ingested_docs:
            col1, col2 = st.columns([4, 1])
            with col1:
                st.markdown(
                    f'<div class="doc-item">📄 {doc}</div>',
                    unsafe_allow_html=True,
                )
            with col2:
                if st.button("🗑️", key=f"del_{doc}", help=f"Remove {doc}"):
                    deleted = delete_document(doc, vector_store)
                    new_chain, new_retriever = build_rag_chain(vector_store)
                    st.session_state.rag_chain = new_chain
                    st.session_state.rag_retriever = new_retriever
                    st.rerun()
    else:
        st.markdown(
            '<div class="badge-info">○ No documents uploaded yet</div>',
            unsafe_allow_html=True,
        )
        st.caption("Upload PDFs above to get started.")

    st.markdown("---")

    # Clear Chat
    if st.button("🗑️ Clear Chat History", use_container_width=True):
        st.session_state.chat_history = []
        st.rerun()

    st.markdown("---")
    st.markdown(
        """
        <div style='color: #4a5568; font-size: 0.75rem; text-align: center;'>
        Built by <strong style='color: #6c63ff;'>Shosi</strong><br>
        RAG Document Intelligence v1.0<br>
        Powered by LangChain + ChromaDB + OpenAI
        </div>
        """,
        unsafe_allow_html=True,
    )


# ─── Main Content ─────────────────────────────────────────────────────────────

# Header
st.markdown("""
<div class="main-header">
    <h1>📄 RAG Document Intelligence System</h1>
    <p>Upload PDFs and ask questions — every answer is grounded in your documents with source citations.</p>
</div>
""", unsafe_allow_html=True)

# Metrics Row
ingested_docs = get_ingested_documents(vector_store)
total_chunks = 0
try:
    all_data = vector_store.get()
    total_chunks = len(all_data.get("ids", []))
except Exception:
    pass

col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Documents Loaded", len(ingested_docs))
with col2:
    st.metric("Knowledge Chunks", total_chunks)
with col3:
    st.metric("Questions Asked", len(st.session_state.chat_history))

st.markdown("---")

# ─── Chat Interface ───────────────────────────────────────────────────────────

# Display chat history
if st.session_state.chat_history:
    st.markdown("### Conversation")
    for entry in st.session_state.chat_history:
        # User question
        with st.chat_message("user"):
            st.write(entry["question"])

        # AI answer with citations
        with st.chat_message("assistant"):
            st.markdown(
                f'<div class="answer-box">{entry["answer"]}</div>',
                unsafe_allow_html=True,
            )

            if entry.get("sources"):
                with st.expander(
                    f"📚 View {len(entry['sources'])} Source Citation(s)", expanded=False
                ):
                    for i, src in enumerate(entry["sources"], 1):
                        st.markdown(
                            f"""
                            <div class="citation-card">
                                <div class="citation-header">
                                    [{i}] 📄 {src['filename']} — Page {src['page']}
                                </div>
                                <div class="citation-excerpt">
                                    "{src['excerpt']}"
                                </div>
                            </div>
                            """,
                            unsafe_allow_html=True,
                        )
            else:
                st.caption("No specific source passages retrieved for this answer.")

    st.markdown("---")

# ─── Question Input ───────────────────────────────────────────────────────────

if not ingested_docs:
    st.info(
        "👈 **Get started:** Upload one or more PDF documents using the sidebar, "
        "then ask any question about their contents."
    )

    # Example use cases
    st.markdown("### What you can do with this system")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("""
        **📋 Policy Analysis**
        Upload HR policies, legal briefs, or compliance documents and instantly find specific clauses.
        """)
    with col2:
        st.markdown("""
        **📊 Research Synthesis**
        Upload multiple research papers and ask cross-document questions with cited answers.
        """)
    with col3:
        st.markdown("""
        **🏢 Product Knowledge**
        Upload product catalogs or technical manuals and get precise, grounded answers.
        """)
else:
    # Question input
    st.markdown("### Ask a Question")

    # Suggested questions
    if ingested_docs:
        st.markdown("**Suggested questions to try:**")
        example_cols = st.columns(3)
        examples = [
            "What is the main purpose of this document?",
            "Summarize the key points in bullet form.",
            "What are the most important requirements or conditions mentioned?",
        ]
        for i, (col, example) in enumerate(zip(example_cols, examples)):
            with col:
                if st.button(f"💡 {example}", key=f"example_{i}", use_container_width=True):
                    st.session_state.prefill_question = example

    # Get prefilled question if any
    prefill = st.session_state.pop("prefill_question", "")

    question = st.text_area(
        "Your question",
        value=prefill,
        placeholder="e.g. What are the key terms and conditions in Section 3?",
        height=100,
        label_visibility="collapsed",
    )

    col_ask, col_spacer = st.columns([1, 3])
    with col_ask:
        ask_button = st.button(
            "🔍 Get Answer",
            use_container_width=True,
            disabled=not question.strip(),
        )

    if ask_button and question.strip():
        with st.spinner("Searching documents and generating answer..."):
            result = query_documents(question, rag_chain, rag_retriever)

        # Add to history
        st.session_state.chat_history.append({
            "question": question,
            "answer": result["answer"],
            "sources": result["sources"],
        })
        st.rerun()
