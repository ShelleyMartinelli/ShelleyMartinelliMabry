"""
RAG Engine — Core backend for the Document Intelligence System.

Uses modern LangChain LCEL (LangChain Expression Language) pipeline.

Embedding strategy:
  - Production: OpenAI text-embedding-3-large (set OPENAI_API_KEY to a real key)
  - Local/sandbox: HuggingFace all-MiniLM-L6-v2 (no API key required)

Chat strategy:
  - Uses OPENAI_API_KEY + OPENAI_API_BASE (supports Manus proxy and real OpenAI)
"""

import os
import hashlib
from pathlib import Path
from typing import List, Dict, Any, Tuple

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_core.documents import Document
from langchain_openai import ChatOpenAI


# ─── Configuration ────────────────────────────────────────────────────────────

CHROMA_PERSIST_DIR = Path(__file__).parent.parent / "chroma_db"
COLLECTION_NAME = "rag_documents"

CHUNK_SIZE = 1000
CHUNK_OVERLAP = 200
TOP_K_RESULTS = 4

# Chat model — uses OPENAI_API_KEY + OPENAI_API_BASE from environment
CHAT_MODEL = "gpt-5-mini"

# Embedding: "openai" requires a real OpenAI API key; "local" uses sentence-transformers
# Auto-detected based on whether OPENAI_EMBED_KEY is set
EMBEDDING_BACKEND = os.environ.get("EMBEDDING_BACKEND", "auto")  # "auto", "openai", "local"


# ─── Embeddings ───────────────────────────────────────────────────────────────

def _get_openai_embeddings():
    """OpenAI text-embedding-3-large (production quality)."""
    from langchain_openai import OpenAIEmbeddings
    embed_key = os.environ.get("OPENAI_EMBED_KEY") or os.environ.get("OPENAI_API_KEY", "")
    return OpenAIEmbeddings(
        model="text-embedding-3-large",
        openai_api_key=embed_key,
        openai_api_base="https://api.openai.com/v1",
    )


def _get_local_embeddings():
    """HuggingFace all-MiniLM-L6-v2 (free, no API key, good quality)."""
    from langchain_huggingface import HuggingFaceEmbeddings
    return HuggingFaceEmbeddings(
        model_name="all-MiniLM-L6-v2",
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True},
    )


def get_embeddings():
    """
    Return the appropriate embeddings backend.
    - If OPENAI_EMBED_KEY is set: use OpenAI text-embedding-3-large
    - Otherwise: use local HuggingFace all-MiniLM-L6-v2 (no API key needed)
    """
    backend = EMBEDDING_BACKEND
    if backend == "auto":
        embed_key = os.environ.get("OPENAI_EMBED_KEY", "")
        backend = "openai" if embed_key else "local"

    if backend == "openai":
        return _get_openai_embeddings()
    else:
        return _get_local_embeddings()


# ─── Vector Store ─────────────────────────────────────────────────────────────

def get_vector_store(embeddings) -> Chroma:
    """Return a persistent ChromaDB vector store."""
    CHROMA_PERSIST_DIR.mkdir(parents=True, exist_ok=True)
    return Chroma(
        collection_name=COLLECTION_NAME,
        embedding_function=embeddings,
        persist_directory=str(CHROMA_PERSIST_DIR),
    )


# ─── Document Ingestion ───────────────────────────────────────────────────────

def _file_hash(filepath: str) -> str:
    """Compute a short SHA-256 hash of a file for deduplication."""
    sha = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha.update(chunk)
    return sha.hexdigest()[:16]


def ingest_pdf(filepath: str, vector_store: Chroma) -> Dict[str, Any]:
    """
    Load a PDF, split into chunks, embed, and store in ChromaDB.
    Returns a summary dict with chunk count and document name.
    Skips re-ingestion if the file hash already exists in the store.
    """
    filename = Path(filepath).name
    file_hash = _file_hash(filepath)

    # Check if already ingested
    try:
        existing = vector_store.get(where={"file_hash": file_hash})
        if existing and existing.get("ids"):
            return {
                "filename": filename,
                "chunks": len(existing["ids"]),
                "status": "already_ingested",
            }
    except Exception:
        pass

    # Load PDF pages
    loader = PyPDFLoader(filepath)
    pages = loader.load()

    if not pages:
        return {"filename": filename, "chunks": 0, "status": "empty_pdf"}

    # Split into overlapping chunks
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(pages)

    # Enrich metadata for citation display
    for chunk in chunks:
        chunk.metadata["source_file"] = filename
        chunk.metadata["file_hash"] = file_hash
        raw_page = chunk.metadata.get("page", None)
        if raw_page is not None:
            chunk.metadata["page_number"] = int(raw_page) + 1
        else:
            chunk.metadata["page_number"] = "N/A"

    # Add to vector store
    vector_store.add_documents(chunks)

    return {
        "filename": filename,
        "chunks": len(chunks),
        "status": "ingested",
    }


def get_ingested_documents(vector_store: Chroma) -> List[str]:
    """Return a sorted list of unique filenames in the vector store."""
    try:
        all_docs = vector_store.get()
        if not all_docs or not all_docs.get("metadatas"):
            return []
        filenames = set()
        for meta in all_docs["metadatas"]:
            if meta and "source_file" in meta:
                filenames.add(meta["source_file"])
        return sorted(list(filenames))
    except Exception:
        return []


def delete_document(filename: str, vector_store: Chroma) -> int:
    """Delete all chunks for a given filename. Returns number of chunks deleted."""
    try:
        existing = vector_store.get(where={"source_file": filename})
        if existing and existing.get("ids"):
            ids_to_delete = existing["ids"]
            vector_store.delete(ids=ids_to_delete)
            return len(ids_to_delete)
        return 0
    except Exception:
        return 0


# ─── RAG Chain (LCEL) ─────────────────────────────────────────────────────────

SYSTEM_PROMPT_TEMPLATE = """You are a precise, trustworthy document analyst. Your job is to answer questions ONLY based on the provided document excerpts.

Rules:
1. Answer ONLY from the provided context. Do NOT use outside knowledge.
2. If the context does not contain enough information to answer, say exactly: "I could not find a clear answer in the uploaded documents."
3. Be concise but thorough. Use bullet points for multi-part answers.
4. Do NOT fabricate facts, statistics, or quotes.
5. Always refer to the source document name when relevant.

Context from documents:
{context}

Question: {question}

Answer:"""

RAG_PROMPT = PromptTemplate(
    template=SYSTEM_PROMPT_TEMPLATE,
    input_variables=["context", "question"],
)


def _format_docs(docs: List[Document]) -> str:
    """Format retrieved documents into a single context string."""
    parts = []
    for doc in docs:
        filename = doc.metadata.get("source_file", "Unknown")
        page = doc.metadata.get("page_number", "N/A")
        parts.append(f"[Source: {filename}, Page {page}]\n{doc.page_content}")
    return "\n\n---\n\n".join(parts)


def build_rag_chain(vector_store: Chroma) -> Tuple:
    """
    Build and return the LCEL RAG chain and retriever.
    Returns: (chain, retriever)
    """
    llm = ChatOpenAI(
        model=CHAT_MODEL,
        temperature=0.1,
        max_tokens=1500,
    )

    retriever = vector_store.as_retriever(
        search_type="similarity",
        search_kwargs={"k": TOP_K_RESULTS},
    )

    # LCEL chain: retrieve → format → prompt → LLM → parse
    chain = (
        {"context": retriever | _format_docs, "question": RunnablePassthrough()}
        | RAG_PROMPT
        | llm
        | StrOutputParser()
    )

    return chain, retriever


def query_documents(
    question: str,
    chain,
    retriever,
) -> Dict[str, Any]:
    """
    Run a query through the RAG chain.
    Returns the answer and a list of deduplicated source citations.
    """
    if not question.strip():
        return {"answer": "Please enter a question.", "sources": []}

    # Get the answer
    answer = chain.invoke(question)

    # Separately retrieve source documents for citation display
    source_docs: List[Document] = retriever.invoke(question)

    # Build deduplicated citation list
    seen = set()
    citations = []
    for doc in source_docs:
        meta = doc.metadata
        filename = meta.get("source_file", "Unknown document")
        page = meta.get("page_number", "N/A")
        key = (filename, str(page))
        if key not in seen:
            seen.add(key)
            excerpt = doc.page_content[:350].strip()
            if len(doc.page_content) > 350:
                excerpt += "..."
            citations.append({
                "filename": filename,
                "page": page,
                "excerpt": excerpt,
            })

    return {
        "answer": answer,
        "sources": citations,
    }
