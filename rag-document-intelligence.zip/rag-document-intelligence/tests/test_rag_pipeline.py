"""
End-to-end test for the RAG Document Intelligence System.
Tests: PDF ingestion, embedding, retrieval, answer generation, and citation output.
"""

import sys
import warnings
import shutil
from pathlib import Path

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Use a temporary ChromaDB dir for testing
import rag_engine
TEST_CHROMA_DIR = Path(__file__).parent.parent / "chroma_db_test"
rag_engine.CHROMA_PERSIST_DIR = TEST_CHROMA_DIR

from rag_engine import (
    get_embeddings,
    get_vector_store,
    ingest_pdf,
    get_ingested_documents,
    delete_document,
    build_rag_chain,
    query_documents,
)

SAMPLE_PDF = Path(__file__).parent.parent / "sample_docs" / "AI_Operations_Policy_Manual.pdf"


def test_full_pipeline():
    print("\n" + "=" * 60)
    print("RAG DOCUMENT INTELLIGENCE — END-TO-END TEST")
    print("=" * 60)

    # ── Step 1: Initialize ──────────────────────────────────────
    print("\n[1/6] Initializing embeddings and vector store...")
    embeddings = get_embeddings()
    vector_store = get_vector_store(embeddings)
    print(f"      ✅ Vector store ready at: {TEST_CHROMA_DIR}")

    # ── Step 2: Ingest PDF ──────────────────────────────────────
    print(f"\n[2/6] Ingesting PDF: {SAMPLE_PDF.name}")
    assert SAMPLE_PDF.exists(), f"Sample PDF not found at {SAMPLE_PDF}"
    result = ingest_pdf(str(SAMPLE_PDF), vector_store)
    print(f"      Status: {result['status']}")
    print(f"      Chunks created: {result['chunks']}")
    assert result["status"] in ("ingested", "already_ingested"), f"Unexpected status: {result['status']}"
    assert result["chunks"] > 0, "No chunks were created"
    print("      ✅ PDF ingested successfully")

    # ── Step 3: Verify document appears in store ────────────────
    print("\n[3/6] Verifying document is in knowledge base...")
    docs = get_ingested_documents(vector_store)
    print(f"      Documents in store: {docs}")
    assert SAMPLE_PDF.name in docs, f"{SAMPLE_PDF.name} not found in store"
    print("      ✅ Document confirmed in knowledge base")

    # ── Step 4: Build RAG chain ─────────────────────────────────
    print("\n[4/6] Building RAG chain...")
    chain, retriever = build_rag_chain(vector_store)
    print(f"      Chain type: {type(chain).__name__}")
    print(f"      Retriever type: {type(retriever).__name__}")
    print("      ✅ Chain built successfully")

    # ── Step 5: Run test queries ────────────────────────────────
    test_questions = [
        "What are the three risk tiers for AI system classification?",
        "What are the data retention requirements in this policy?",
        "What performance standards must production AI systems meet?",
    ]

    print("\n[5/6] Running test queries...")
    for i, question in enumerate(test_questions, 1):
        print(f"\n      Query {i}: {question}")
        result = query_documents(question, chain, retriever)

        answer = result["answer"]
        sources = result["sources"]

        print(f"      Answer (first 200 chars): {answer[:200]}...")
        print(f"      Citations returned: {len(sources)}")

        for src in sources:
            print(f"        → [{src['filename']}] Page {src['page']}")

        assert answer, "Answer should not be empty"
        assert len(answer) > 20, "Answer is suspiciously short"
        assert sources, "Citations should not be empty for this query"
        assert all("filename" in s and "page" in s and "excerpt" in s for s in sources), \
            "Each citation must have filename, page, and excerpt fields"

    print("\n      ✅ All queries returned answers with citations")

    # ── Step 6: Test deduplication ──────────────────────────────
    print("\n[6/6] Testing re-ingestion deduplication...")
    result2 = ingest_pdf(str(SAMPLE_PDF), vector_store)
    assert result2["status"] == "already_ingested", "Should detect duplicate"
    print("      ✅ Duplicate detection works correctly")

    # ── Cleanup ─────────────────────────────────────────────────
    print("\n[Cleanup] Removing test ChromaDB...")
    if TEST_CHROMA_DIR.exists():
        shutil.rmtree(TEST_CHROMA_DIR)
    print("          ✅ Test database cleaned up")

    print("\n" + "=" * 60)
    print("ALL TESTS PASSED ✅")
    print("=" * 60)


if __name__ == "__main__":
    test_full_pipeline()
