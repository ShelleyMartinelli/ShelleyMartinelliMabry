# RAG Document Intelligence System

> **An autonomous document analysis pipeline that grounds every LLM answer in verifiable source citations, eliminating hallucinations.**

[![Python](https://img.shields.io/badge/Python-3.11-blue?style=for-the-badge&logo=python)](https://python.org)
[![LangChain](https://img.shields.io/badge/LangChain-Latest-1C3C3C?style=for-the-badge)](https://langchain.com)
[![Streamlit](https://img.shields.io/badge/Streamlit-App-FF4B4B?style=for-the-badge&logo=streamlit)](https://streamlit.io)
[![OpenAI](https://img.shields.io/badge/OpenAI-GPT--4o--mini-412991?style=for-the-badge)](https://openai.com)

---

## 🎯 The Problem

Enterprise teams spend 20–30% of their day searching through dense policy manuals, legal briefs, and product catalogs. While standard LLMs can summarize text, they frequently hallucinate facts and cannot be trusted for critical operations. 

This project solves that by implementing a **Retrieval-Augmented Generation (RAG)** pipeline. It ensures that every generated answer is strictly grounded in the uploaded documents and provides exact page-level citations for human verification.

---

## 🏗️ Architecture

```
[User Uploads PDF]
         ↓
[PyPDF Loader & Text Splitter] → Overlapping chunks (1000 chars)
         ↓
[OpenAI Embeddings] → text-embedding-3-large
         ↓
[ChromaDB Vector Store] → Persistent local storage
         ↓
[User Asks Question]
         ↓
[Similarity Search] → Top 4 most relevant chunks retrieved
         ↓
[LangChain LCEL Pipeline] → Formats chunks + strict grounding prompt
         ↓
[GPT-4o-mini Generation] → Synthesizes answer
         ↓
[Streamlit Frontend] → Displays Answer + Source Citations (Filename & Page)
```

---

## ⚙️ Tech Stack

| Component | Technology | Why I Chose It |
|---|---|---|
| **Orchestration** | LangChain (LCEL) | The modern RunnablePassthrough syntax is cleaner, faster, and more debuggable than legacy chains. |
| **Embeddings** | OpenAI `text-embedding-3-large` | Industry standard for dense semantic search; significantly outperforms older models on technical text. |
| **Vector Store** | ChromaDB | Local-first, persistent storage. Eliminates the need for a separate cloud database during prototyping. |
| **LLM** | OpenAI `gpt-4o-mini` | High reasoning capability at a fraction of the cost of GPT-4, perfect for strict context-synthesis tasks. |
| **Frontend** | Streamlit | Rapid prototyping framework that handles file uploads and session state out-of-the-box. |

---

## 🚀 How to Run Locally

### Prerequisites
- Python 3.10+
- An OpenAI API key

### Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/YOUR_USERNAME/rag-document-intelligence.git
   cd rag-document-intelligence
   ```

2. **Create a virtual environment:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables:**
   ```bash
   cp .env.example .env
   ```
   Open `.env` and add your `OPENAI_API_KEY`.

5. **Run the application:**
   ```bash
   streamlit run app.py
   ```
   Navigate to `http://localhost:8501` in your browser.

---

## ☁️ How to Deploy to Streamlit Community Cloud (Free)

1. Push this repository to your GitHub account.
2. Go to [share.streamlit.io](https://share.streamlit.io) and log in with GitHub.
3. Click **"New app"**.
4. Select your repository, branch (`main`), and main file path (`app.py`).
5. Click **"Advanced settings"** and paste your `.env` contents into the Secrets box:
   ```toml
   OPENAI_API_KEY="sk-your-api-key-here"
   ```
6. Click **Deploy!**

---

## 🧠 Engineering Decisions

**Why explicit chunk overlap?**  
When splitting dense PDFs, hard cuts often slice a sentence in half, destroying semantic meaning. By implementing a 200-character overlap, the embedding model maintains the context between adjacent chunks, drastically improving retrieval accuracy.

**Why deduplication by SHA-256 hash?**  
In production, users frequently re-upload the same file. The ingestion pipeline computes a file hash and checks ChromaDB before embedding. This prevents duplicate vector pollution and saves unnecessary API costs.

**Why separate the Retriever in the LCEL chain?**  
Standard LCEL chains swallow the source documents after generating the answer. By returning a `(chain, retriever)` tuple from the backend, the Streamlit frontend can execute a parallel retrieval to display the exact filename, page number, and excerpt to the user.

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

*Built by [Shosi](https://github.com/YOUR_USERNAME) | AI Operations Engineer*
